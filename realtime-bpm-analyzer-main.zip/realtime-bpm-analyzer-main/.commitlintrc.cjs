const commitlint = {
  extends: ['@commitlint/config-conventional']
};

module.exports = commitlint;

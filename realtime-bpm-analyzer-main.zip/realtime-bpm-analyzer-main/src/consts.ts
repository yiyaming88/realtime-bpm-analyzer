export const realtimeBpmProcessorName = 'realtime-bpm-processor';
export const startThreshold = 0.95;
export const minValidThreshold = 0.2;
export const minPeaks = 15;
export const thresholdStep = 0.05;
export const frequencyValue = 200;
export const qualityValue = 1;

